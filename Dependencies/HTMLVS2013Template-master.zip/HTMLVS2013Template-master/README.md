HTMLVS2013Template
==================

Visual Studio 2013 HTML Template File Based On Pure HTML template for Visual Studio (purehtml.codeplex.com)
